
import Foundation

enum MenuCategory: String {
    case food, drink, dessert
}
