//
//  SortOption.swift
//  Menu
//
//  Created by MyMac on 2022-11-08.
//

import Foundation

enum SortOption {
    case popularity
    case price
    case alphabetical
}
