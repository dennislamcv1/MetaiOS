//
//  MenuCategory.swift
//  Menu
//
//  Created by Developer on 2022-09-16.
//

import Foundation

enum MenuCategory: String {
    case food, drink, dessert
}
