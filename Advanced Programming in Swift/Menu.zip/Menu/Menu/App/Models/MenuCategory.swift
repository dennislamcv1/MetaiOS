//
//  MenuCategory.swift
//  Menu
//
//

import Foundation

enum MenuCategory: String {
    case food
    case drink
    case dessert
}
