//
//  SortOption.swift
//  Menu
//
//

import Foundation

enum SortOption {
    case popularity
    case price
    case alphabetical
}
